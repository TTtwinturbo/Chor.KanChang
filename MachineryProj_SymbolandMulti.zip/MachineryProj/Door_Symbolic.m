clear; clc; close all

%% 0. PARAMETERS
% ---- ground ----
P.r2       = 30;        
P.r4       = 30;        
P.sweep    = -90;       
P.tilt     = 0;        
P.tiltAz   = 0;        
% ---- links ----
P.L2       = 75;       
P.L3       = [];       
P.L4       = [];        
P.zIn      = [0 62];    
P.zOut     = 17;       
P.zGround  = [-6 62];  
% ---- bevel pair ----
P.module   = 1;        
P.z1       = 20;        
P.z2       = 20;       
P.zApex    = 30;        
P.gearSign = 0;         
% ---- door ----
P.side      = "left";   
P.doorAlign = "crank";  
                       
                        
P.doorDir  = 0;         
P.doorXi   = [-85 135]; 
P.doorEta  = [-50 50];  
P.doorOff  = 14;        
% ---- motion: the stops are external (door frame / end stop) ----
P.th2Closed = 180;       
P.th2Open   = 90;      
P.branch    = 0;       
P.muWarn    = 40;      
P.muStop    = 15;       
% ---- output ----
P.N        = 61;           
P.animMode = "fanimator";   
P.view     = [];           
P.gifFile  = "door.gif";            

C = struct('inp',[42 120 214]/255, 'outp',[235 104 52]/255, 'coup',[27 175 122]/255, ...
           'gear',[237 161 0]/255, 'door',[154 163 173]/255, 'ground',[58 58 56]/255, ...
           'ink',[11 11 11]/255, 'ink2',[82 81 78]/255, 'band',[228 227 223]/255);

%% 1. GROUND GEOMETRY
O2  = [P.r2; 0];
O4  = P.r4*[cosd(P.sweep); sind(P.sweep)];
L1  = norm(O4 - O2);
th1 = atan2(O4(2) - O2(2), O4(1) - O2(1));            % ground-line angle
if isempty(P.L3), P.L3 = L1;   end
if isempty(P.L4), P.L4 = P.L2; end
Ls      = sort([L1 P.L2 P.L3 P.L4]);
isPara  = abs(P.L3 - L1) < 1e-9 && abs(P.L4 - P.L2) < 1e-9;
grashof = Ls(1) + Ls(4) <= Ls(2) + Ls(3) + 1e-9;
fprintf('Ground : O2 = (%.2f, %.2f), O4 = (%.2f, %.2f) mm, L1 = %.3f mm, theta1 = %.2f deg\n', ...
        O2, O4, L1, rad2deg(th1));
fprintf('Links  : L2 = %.3f, L3 = %.3f, L4 = %.3f mm  ->  %s, %s\n', P.L2, P.L3, P.L4, ...
        pick(isPara, 'parallelogram', 'general four-bar'), pick(grashof, 'Grashof', 'non-Grashof'));
Rt = rodrigues([-sind(P.tiltAz); cosd(P.tiltAz); 0], deg2rad(P.tilt));   % hinge frame H -> world W

%% 2. SYMBOLIC UNKNOWNS AND LOOP-CLOSURE EQUATIONS (same form as the 2-D homework)
syms th2 th3 th4 real
syms O2x O2y O4x O4y l2 l3 l4 sig real
pSym = [O2x O2y O4x O4y l2 l3 l4];
A_x = O2x + l2*cos(th2);   A_y = O2y + l2*sin(th2);
B_x = O4x + l4*cos(th4);   B_y = O4y + l4*sin(th4);
linkAB_x = B_x == A_x + l3*cos(th3);
linkAB_y = B_y == A_y + l3*sin(th3);

%% 3. CLOSED-FORM POSITION SOLUTION (replaces solve(): no root-ordering ambiguity)
dX    = O4x - A_x;   dY = O4y - A_y;
D     = sqrt(dX^2 + dY^2);
gam   = atan2(dY, dX);
cBeta = (l3^2 + D^2 - l4^2)/(2*l3*D);         
th3_s = gam + sig*acos(cBeta);                 
Bx_s  = A_x + l3*cos(th3_s);
By_s  = A_y + l3*sin(th3_s);
th4_s = atan2(By_s - O4y, Bx_s - O4x);
cMu   = (l3^2 + l4^2 - D^2)/(2*l3*l4);        
resid = subs([lhs(linkAB_x) - rhs(linkAB_x); lhs(linkAB_y) - rhs(linkAB_y)], [th3 th4], [th3_s th4_s]);

fKin1 = matlabFunction([A_x; A_y; Bx_s; By_s; th3_s; th4_s; cBeta; cMu], 'Vars', {th2, sig, pSym});
fKin  = @(t, s, p) cell2mat(arrayfun(@(tt) fKin1(tt, s, p), t, 'UniformOutput', false));  % 8 x numel(t)
pv    = [O2.' O4.' P.L2 P.L3 P.L4];

%% 4. STOPS, ASSEMBLY MODE AND MOTION RANGE
isLeftReq = strcmpi(P.side, 'left');
sideSgn   = pick(isLeftReq, -1, +1);                   
if isempty(P.th2Closed), P.th2Closed = rad2deg(th1) + sideSgn*45; end
if isempty(P.th2Open),   P.th2Open   = P.th2Closed + sideSgn*90;  end
th2c = deg2rad(P.th2Closed);   th2o = deg2rad(P.th2Open);
dirn = sign(th2o - th2c);
if dirn == 0, error('th2Open must differ from th2Closed.'); end

kc = [fKin(th2c, +1, pv), fKin(th2c, -1, pv)];
if abs(real(kc(7,1))) > 1
    sDeg = 0:0.5:359.5;   kS = fKin(deg2rad(sDeg), 1, pv);
    error('Cannot assemble at th2Closed = %.1f deg. Assemblable input ranges [deg]: %s', ...
          P.th2Closed, rangesText(sDeg, abs(real(kS(7,:))) <= 1));
end
if P.branch == 0
    [~, j] = min(abs(wrapPi(real(kc(5,:)) - th1)));
    sigma  = 3 - 2*j;                                  
else
    sigma  = P.branch;
end

% scan one full revolution from the closed stop in the opening direction
scanDeg = 0:0.25:360;
kS   = fKin(th2c + dirn*deg2rad(scanDeg), sigma, pv);
okS  = abs(real(kS(7,:))) <= 1;
muS  = acosd(max(min(real(kS(8,:)), 1), -1));
mupS = min(muS, 180 - muS);                            
mupS(~okS) = 0;
limWarn = swingLimit(scanDeg, find(mupS < P.muWarn, 1));
limStop = swingLimit(scanDeg, find(mupS < P.muStop, 1));
swing   = abs(P.th2Open - P.th2Closed);
fprintf('Stops  : closed %.1f deg -> open %.1f deg (%.1f deg %s), assembly mode sigma = %+d\n', ...
        P.th2Closed, P.th2Open, swing, pick(dirn > 0, 'CCW', 'CW'), sigma);
fprintf('Range  : %.1f deg with mu in [%g, %g] deg; %.1f deg before mu'' < %g deg (change/toggle point)\n', ...
        limWarn, P.muWarn, 180 - P.muWarn, limStop, P.muStop);
if swing > limStop
    error('Open stop lies beyond the usable range (%.1f deg). Move th2Closed/th2Open.', limStop);
elseif swing > limWarn
    warning('Swing exceeds the %.1f deg range with good transmission (mu inside [%g, %g] deg).', ...
            limWarn, P.muWarn, 180 - P.muWarn);
end
res = double(subs(resid, [th2 sig pSym], [th2c sigma pv]));
fprintf('Check  : symbolic loop-closure residual at the closed stop = %.2e mm\n', norm(res));

%% 5. POSITION ANALYSIS OVER THE SWING
th2v = linspace(th2c, th2o, P.N);
K    = real(fKin(th2v, sigma, pv));
Av = K(1:2,:);   Bv = K(3:4,:);   th3v = K(5,:);
muv  = acosd(max(min(K(8,:), 1), -1));

%% 6. BEVEL (MITER) GEAR LAW — symbolic
syms th2c_s th3c_s zz1 zz2 sg real
phi_s = sg*(zz1/zz2)*((th2 - th3) - (th2c_s - th3c_s));
fPhi  = matlabFunction(phi_s, 'Vars', {th2, th3, th2c_s, th3c_s, zz1, zz2, sg});
R1 = P.module*P.z1/2;   R2 = P.module*P.z2/2;     

%% 7. DOOR SHAFT, DOOR AXES (closed pose) AND GEAR SIGN
ez   = [0; 0; 1];
eCr  = [cos(th2c); sin(th2c); 0];                 
if isnumeric(P.doorAlign)
    alignMode = "angle";   nH0 = [cosd(P.doorAlign); sind(P.doorAlign); 0];
else
    alignMode = lower(string(P.doorAlign));
    if alignMode == "crank"                            
        nH0 = [cos(th2c + dirn*pi/2); sin(th2c + dirn*pi/2); 0];
    else                                          
        chord = Av(:,end) - Av(:,1);   nH0 = [chord/norm(chord); 0];
    end
end
nW0    = Rt*nH0;
xiPlus = cross(ez, nW0);   xiPlus = xiPlus/norm(xiPlus);  
if alignMode == "crank"
    dd = sign(dot(xiPlus, Rt*eCr));               
elseif P.doorDir == 0
    cBase = [mean([O2 O4], 2) - Av(:,1); 0];      
    dd = -sign(dot(Rt.'*xiPlus, cBase));
else
    dd = P.doorDir;
end
if dd == 0, dd = 1; end
xi0W  = dd*xiPlus;                                
eta0W = cross(nW0, xi0W);   if eta0W(3) < 0, eta0W = -eta0W; end   
xi0H  = Rt.'*xi0W;   eta0H = Rt.'*eta0W;

fwdW   = -xi0W;
isLeft = dot(cross(ez, fwdW), nW0) > 0;          
if isLeft ~= isLeftReq
    msg = sprintf('Geometry gives a %s door but P.side = "%s".', pick(isLeft, 'LEFT', 'RIGHT'), P.side);
    if alignMode == "crank"
        error('%s With doorAlign = "crank" a left door needs a CW crank swing seen from above (th2Open < th2Closed), a right door CCW.', msg);
    else
        warning('%s Flip P.doorDir or the swing direction.', msg);
    end
end
eCrW = Rt*eCr;
angDC = acosd(min(1, abs(dot(eCrW(1:2), xi0W(1:2)))/(norm(eCrW(1:2))*norm(xi0W(1:2)))));
fprintf('Door   : %s door, closed long axis vs cranks (plan) = %.2f deg\n', pick(isLeft, 'LEFT', 'RIGHT'), angDC);
if isempty(P.view)
    v = fwdW + nW0;   P.view = [atan2d(v(2), v(1)) + 90, 24];   
end
relEnd = (th2v(end) - th3v(end)) - (th2v(1) - th3v(1));
if P.gearSign == 0
    sGear = sign((ez.'*cross(nW0, xi0W))*relEnd);   if sGear == 0, sGear = 1; end
else
    sGear = P.gearSign;
end
xiE = P.doorXi([1 2 2 1]);   etE = P.doorEta([1 1 2 2]);
qH  = xi0H*xiE + eta0H*etE + P.doorOff*nH0;      
fprintf('Gears  : z1/z2 = %d/%d, crank gear %s the apex (s = %+d), centre z = %.1f mm; upper input bar z = %.1f mm\n', ...
        P.z1, P.z2, pick(sGear > 0, 'BELOW', 'ABOVE'), sGear, P.zApex - sGear*R2, P.zIn(2));
if P.doorOff <= R1, warning('doorOff (%.1f) <= shaft-gear distance R1 (%.1f): panel hits the gear.', P.doorOff, R1); end

%% 8. DOOR POSE — symbolic homogeneous transformation chain
%   P_W = R_tilt * T_A(theta2) * T_coupler(dth3) * T_shaft(n0, phi) * [q; 1]
syms ax_ ay_ za_ dth3 phi nx ny real
Rz3  = [cos(dth3) -sin(dth3) 0; sin(dth3) cos(dth3) 0; 0 0 1];
Kn   = [0 0 ny; 0 0 -nx; -ny nx 0];                
Rn   = eye(3) + sin(phi)*Kn + (1 - cos(phi))*Kn^2;  
T_A  = [eye(3) [ax_; ay_; za_]; 0 0 0 1];
T_C  = [Rz3 zeros(3,1); 0 0 0 1];
T_S  = [Rn  zeros(3,1); 0 0 0 1];
T_HD = T_A*T_C*T_S;                               
fT   = matlabFunction(T_HD, 'Vars', {ax_, ay_, za_, dth3, phi, [nx ny]});

Dd = struct('fKin',fKin, 'fPhi',fPhi, 'fT',fT, 'pv',pv, 'sig',sigma, 'th2c',th2c, 'th3c',th3v(1), ...
            's',sGear, 'R1',R1, 'R2',R2, 'nH0',nH0, 'xi0H',xi0H, 'eta0H',eta0H, 'xi0W',xi0W, ...
            'qH',qH, 'Rt',Rt, 'O2',O2, 'O4',O4, 'P',P);
for i = P.N:-1:1
    pose(i) = poseAt(th2v(i), Dd);
end

%% 9. VALIDATION
pitch = [pose.pitch];   yaw = [pose.yaw];
errL3 = max(abs(vecnorm(Bv - Av) - P.L3));
errL4 = max(abs(vecnorm(Bv - O4) - P.L4));
drift = max(abs(rad2deg(th3v - th3v(1))));
tipZ  = arrayfun(@(p) max(p.door(3,:)), pose);
apexTravel = norm(pose(end).apex - pose(1).apex);
fprintf('\n================ SUMMARY ================\n');
fprintf('Closure error |AB|-L3 = %.1e mm, |O4B|-L4 = %.1e mm\n', errL3, errL4);
fprintf('Coupler rotation over swing = %.3f deg %s\n', drift, pick(drift < 1e-6, '(pure translation)', ''));
fprintf('Transmission angle %.1f -> %.1f deg (closest to change point: %.1f deg)\n', ...
        muv(1), muv(end), min(min(muv, 180 - muv)));
fprintf('Door pitch %.2f -> %.2f deg, door yaw change %.2f deg, shaft travel %.1f mm\n', ...
        pitch(1), pitch(end), max(yaw) - min(yaw), apexTravel);
if any(diff(tipZ) < -1e-9), warning('Door tip does not rise monotonically.'); end
fprintf('=========================================\n');

%% 10. STATIC 3-D POSES
allPts = [pose.all];
lims   = [min(allPts, [], 2) max(allPts, [], 2)] + [-10 10];
iShow  = [1 ceil(P.N/2) P.N];
names  = ["Closed", "Mid-swing", "Open (stop)"];
f1  = figure('Name', 'Poses', 'Color', 'w', 'Position', [40 80 1500 540]);
tl1 = tiledlayout(f1, 1, 3, 'TileSpacing', 'compact', 'Padding', 'compact');
for k = 1:3
    ax = nexttile(tl1);   hold(ax, 'on');
    drawPaths(ax, pose, C);
    drawPose(ax, pose(iShow(k)), C, 1);
    setup3D(ax, lims, P.view);
    title(ax, sprintf('%s:  \\theta_2 = %.1f^{\\circ},  pitch = %.1f^{\\circ}', ...
          names(k), rad2deg(th2v(iShow(k))), pitch(iShow(k))));
end
title(tl1, sprintf('Dihedral synchro-helix door, %s side  (mm)', pick(isLeft, 'LEFT', 'RIGHT')));

%% 11. PLAN VIEW AND SIDE ELEVATION
f2  = figure('Name', 'Plan & side views', 'Color', 'w', 'Position', [60 80 1300 520]);
tl2 = tiledlayout(f2, 1, 2, 'TileSpacing', 'compact', 'Padding', 'compact');
alph = [0.3 0.55 1];
ax = nexttile(tl2);   hold(ax, 'on');
for k = 1:3
    G = pose(iShow(k));   a = alph(k);
    plot(ax, G.input{2}(1,:), G.input{2}(2,:), 'Color', tint(C.inp, a),  'LineWidth', 2.5);
    plot(ax, G.output(1,:),   G.output(2,:),   'Color', tint(C.outp, a), 'LineWidth', 2.5);
    plot(ax, G.coupler(1,1:2), G.coupler(2,1:2), 'Color', tint(C.coup, a), 'LineWidth', 2.5);
    plot(ax, G.shaft(1,:),    G.shaft(2,:),    'Color', tint(C.ink, a),  'LineWidth', 1.8);
    plot(ax, G.door(1,[1:4 1]), G.door(2,[1:4 1]), 'Color', tint(C.ink2, a), 'LineWidth', 1.3);
end
Ap = [pose.Aup];   Bp = [pose.Bout];
plot(ax, Ap(1,:), Ap(2,:), ':', 'Color', C.inp, 'LineWidth', 1.2);
plot(ax, Bp(1,:), Bp(2,:), ':', 'Color', C.outp, 'LineWidth', 1.2);
O2w = Rt*[O2; 0];   O4w = Rt*[O4; 0];               % ground pivots at z = 0 (world)
plot(ax, [0 O2w(1)], [0 O2w(2)], '--', 'Color', C.ink2);
plot(ax, [0 O4w(1)], [0 O4w(2)], '--', 'Color', C.ink2);
plot(ax, [O2w(1) O4w(1)], [O2w(2) O4w(2)], '^', 'MarkerSize', 9, 'MarkerFaceColor', C.ground, 'Color', C.ground);
text(ax, O2w(1) + 4, O2w(2) - 4, 'O_2');   text(ax, O4w(1) + 4, O4w(2) - 4, 'O_4');
text(ax, 6, 4, sprintf('%g^{\\circ} ground sweep', P.sweep), 'Color', C.ink2);
hingePts = [[0;0] O2w(1:2) O4w(1:2) Ap(1:2,:) Bp(1:2,:)];
axis(ax, 'equal');   grid(ax, 'on');
xlim(ax, [min(hingePts(1,:)) max(hingePts(1,:))] + [-25 25]);
ylim(ax, [min(hingePts(2,:)) max(hingePts(2,:))] + [-25 25]);
o0 = [min(hingePts(1,:)) - 12; max(hingePts(2,:)) + 10];   % car-axes marker
nP = nW0(1:2)/norm(nW0(1:2));   fP = fwdW(1:2);
quiver(ax, o0(1)*[1 1], o0(2)*[1 1], 18*[fP(1) nP(1)], 18*[fP(2) nP(2)], 0, 'Color', C.ink, 'LineWidth', 1.2);
text(ax, o0(1) + 24*fP(1), o0(2) + 24*fP(2), 'front', 'HorizontalAlignment', 'center');
text(ax, o0(1) + 24*nP(1), o0(2) + 24*nP(2), 'outboard', 'HorizontalAlignment', 'center');
xlabel(ax, 'x [mm]');   ylabel(ax, 'y [mm]');
title(ax, 'Plan view: closed \rightarrow mid \rightarrow open (faint \rightarrow solid)');

ax = nexttile(tl2);   hold(ax, 'on');
hv = cross(ez, nW0);   hv = hv/norm(hv);        
pr = @(X) [hv.'*X; X(3,:)];                       
for k = 1:3
    G = pose(iShow(k));   a = alph(k);   dp = pr(G.door);
    patch(ax, dp(1,:), dp(2,:), C.door, 'FaceAlpha', 0.35*a, 'EdgeColor', tint(C.ink2, a));
    for m = 1:2
        g2 = pr(G.ground{m});   plot(ax, g2(1,:), g2(2,:), 'Color', tint(C.ground, a), 'LineWidth', 3);
        i2 = pr(G.input{m});    plot(ax, i2(1,:), i2(2,:), 'Color', tint(C.inp, a),    'LineWidth', 2.5);
    end
    o2 = pr(G.output);   plot(ax, o2(1,:), o2(2,:), 'Color', tint(C.outp, a), 'LineWidth', 2.5);
end
for c = [2 3]
    Dc = pr(cell2mat(arrayfun(@(p) p.door(:,c), pose, 'UniformOutput', false)));
    plot(ax, Dc(1,:), Dc(2,:), '--', 'Color', C.ink2);
end
axis(ax, 'equal');   grid(ax, 'on');
xlabel(ax, sprintf('longitudinal [mm]   (front on the %s)', pick(dot(hv, fwdW) > 0, 'right', 'left')));
ylabel(ax, 'z [mm]');
title(ax, 'Side elevation from outboard: door pitches in its own plane');

%% 12. VALIDATION PLOTS
th2d = rad2deg(th2v);
f3  = figure('Name', 'Validation', 'Color', 'w', 'Position', [80 80 1100 700]);
tl3 = tiledlayout(f3, 2, 2, 'TileSpacing', 'compact', 'Padding', 'compact');
ax = nexttile(tl3);   hold(ax, 'on');
plot(ax, th2d, pitch, 'Color', C.inp, 'LineWidth', 2);
plot(ax, th2d, (P.z1/P.z2)*abs(th2d - th2d(1)), '--', 'Color', C.ink2);
legend(ax, 'door pitch', 'ideal (z_1/z_2)|\Delta\theta_2|', 'Location', 'northwest');
grid(ax, 'on');   xlabel(ax, '\theta_2 [deg]');   ylabel(ax, 'pitch [deg]');   title(ax, 'Door pitch');
xDir = pick(dirn < 0, 'reverse', 'normal');       
set(ax, 'XDir', xDir);
ax = nexttile(tl3);
plot(ax, th2d, rad2deg(th3v), 'Color', C.coup, 'LineWidth', 2);
ylim(ax, rad2deg(th3v(1)) + [-1 1]*max(5, 1.2*drift));
grid(ax, 'on');   xlabel(ax, '\theta_2 [deg]');   ylabel(ax, '\theta_3 [deg]');
title(ax, 'Coupler angle (flat = pure translation)');   set(ax, 'XDir', xDir);
ax = nexttile(tl3);   hold(ax, 'on');
patch(ax, th2d([1 end end 1]), [P.muWarn P.muWarn 180-P.muWarn 180-P.muWarn], C.band, 'EdgeColor', 'none');
plot(ax, th2d, muv, 'Color', C.outp, 'LineWidth', 2);
ylim(ax, [0 180]);   grid(ax, 'on');
xlabel(ax, '\theta_2 [deg]');   ylabel(ax, '\mu [deg]');   title(ax, 'Transmission angle (band = recommended)');
set(ax, 'XDir', xDir);
ax = nexttile(tl3);   hold(ax, 'on');
patch(ax, [0 swing swing 0], [0 0 90 90], C.inp, 'FaceAlpha', 0.15, 'EdgeColor', 'none');
plot(ax, scanDeg, mupS, 'Color', C.ink2, 'LineWidth', 1.5);
yline(ax, P.muWarn, '--', 'Color', C.outp);
xline(ax, limWarn, '-', sprintf('limit %.1f^{\\circ}', limWarn), 'Color', C.outp);
xlim(ax, [0 360]);   ylim(ax, [0 92]);   grid(ax, 'on');
xlabel(ax, 'swing from closed stop [deg]');   ylabel(ax, 'min(\mu, 180-\mu) [deg]');
title(ax, 'Distance from change point, full revolution (shaded = chosen swing)');

%% 13. ANIMATION (closed -> open -> closed)
th2ofT = @(t) th2c + (1 - abs(1 - t))*(th2o - th2c);     
switch P.animMode
    case "fanimator"
        f4 = figure('Name', 'Animation (fanimator)', 'Color', 'w');
        ax4 = axes(f4);   hold(ax4, 'on');
        drawPaths(ax4, pose, C);   setup3D(ax4, lims, P.view);
        ok = true;
        try
            fanimator(ax4, @(t) drawPose(ax4, poseAt(th2ofT(double(t)), Dd), C, 1), ...
                      'AnimationRange', [0 2], 'FrameRate', P.N - 1);
            playAnimation(f4);
        catch ME
            ok = false;
            warning('fanimator failed (%s). Falling back to the loop animation.', ME.message);
            close(f4);
            animateLoop(Dd, pose, lims, C, P, th2ofT);
        end
        if ok && strlength(P.gifFile) > 0
            try, writeAnimation(f4, P.gifFile); catch ME, warning('GIF export failed: %s', ME.message); end
        end
    case "loop"
        animateLoop(Dd, pose, lims, C, P, th2ofT);
end

%% ===================== LOCAL FUNCTIONS =====================
function G = poseAt(th2, D)

P    = D.P;   ez = [0; 0; 1];
k    = real(D.fKin(th2, D.sig, D.pv));
A    = k(1:2);   B = k(3:4);   th3 = k(5);
dth3 = th3 - D.th3c;
phi  = D.fPhi(th2, th3, D.th2c, D.th3c, P.z1, P.z2, D.s);
T    = D.fT(A(1), A(2), P.zApex, dth3, phi, D.nH0(1:2).');
Rd   = T(1:3,1:3);
apex = [A; P.zApex];
nH   = [cos(dth3) -sin(dth3) 0; sin(dth3) cos(dth3) 0; 0 0 1]*D.nH0;
W    = @(X) D.Rt*X;
zlo  = min([P.zIn P.zOut]) - 4;   zhi = max([P.zIn P.zOut]) + 4;
c1   = apex - D.s*D.R2*ez;                
c2   = apex + D.R1*nH;                  
G.th2     = th2;   G.phi = phi;
G.ground  = {W([D.O2 D.O2; P.zGround]), W([D.O4 D.O4; P.zGround])};
G.input   = {W([D.O2 A; P.zIn(1) P.zIn(1)]), W([D.O2 A; P.zIn(2) P.zIn(2)])};
G.output  = W([D.O4 B; P.zOut P.zOut]);
G.coupler = W([A B B A; zlo zlo zhi zhi]);
G.pins    = {W([A A; zlo-2 zhi+2]), W([B B; zlo-2 zhi+2])};
G.gear1   = W(circlePts(c1, ez, D.R1));
G.gear2   = W(circlePts(c2, nH, D.R2));
G.spokes  = {W([c1, c1 + D.R1*[cos(th2); sin(th2); 0]]), W([c2, c2 + D.R2*(Rd*D.eta0H)])};
G.shaft   = W([apex, apex + P.doorOff*nH]);
Dp        = T*[D.qH; ones(1, 4)];
G.door    = W(Dp(1:3,:));
G.apex    = W(apex);
G.Aup     = W([A; P.zIn(2)]);
G.Bout    = W([B; P.zOut]);
xiW       = D.Rt*Rd*D.xi0H;
G.pitch   = atan2d(xiW(3), dot(xiW, D.xi0W)); 
nW        = D.Rt*nH;
G.yaw     = atan2d(nW(2), nW(1));
G.all     = [G.ground{:}, G.input{:}, G.output, G.coupler, G.gear1, G.gear2, G.door];
end

function h = drawPose(ax, G, C, a)
h = gobjects(0, 1);
for m = 1:2, h(end+1,1) = line3(ax, G.ground{m}, tint(C.ground, a), 4); end
for m = 1:2, h(end+1,1) = line3(ax, G.input{m},  tint(C.inp, a), 3);    end
h(end+1,1) = line3(ax, G.output, tint(C.outp, a), 3);
h(end+1,1) = patch(ax, 'XData', G.coupler(1,:), 'YData', G.coupler(2,:), 'ZData', G.coupler(3,:), ...
                   'FaceColor', C.coup, 'FaceAlpha', 0.35*a, 'EdgeColor', C.coup);
for m = 1:2, h(end+1,1) = line3(ax, G.pins{m}, C.ink, 1.2); end
for X = {G.gear1, G.gear2}
    h(end+1,1) = patch(ax, 'XData', X{1}(1,:), 'YData', X{1}(2,:), 'ZData', X{1}(3,:), ...
                       'FaceColor', C.gear, 'FaceAlpha', 0.85*a, 'EdgeColor', [168 114 0]/255);
end
for m = 1:2, h(end+1,1) = line3(ax, G.spokes{m}, C.ink, 1); end
h(end+1,1) = line3(ax, G.shaft, C.ink, 2);
h(end+1,1) = patch(ax, 'XData', G.door(1,:), 'YData', G.door(2,:), 'ZData', G.door(3,:), ...
                   'FaceColor', C.door, 'FaceAlpha', 0.55*a, 'EdgeColor', C.ink2);
end

function drawPaths(ax, pose, C)
Ap = [pose.Aup];   Bp = [pose.Bout];
plot3(ax, Ap(1,:), Ap(2,:), Ap(3,:), ':', 'Color', C.inp,  'LineWidth', 1.2);
plot3(ax, Bp(1,:), Bp(2,:), Bp(3,:), ':', 'Color', C.outp, 'LineWidth', 1.2);
for c = [2 3]                                 
    Dc = cell2mat(arrayfun(@(p) p.door(:,c), pose, 'UniformOutput', false));
    plot3(ax, Dc(1,:), Dc(2,:), Dc(3,:), '--', 'Color', C.ink2, 'LineWidth', 1);
end
end

function animateLoop(D, pose, lims, C, P, th2ofT)
f  = figure('Name', 'Animation (loop)', 'Color', 'w');
ax = axes(f);   hold(ax, 'on');
drawPaths(ax, pose, C);   setup3D(ax, lims, P.view);
tSeq = linspace(0, 2, 2*P.N - 1);
h = gobjects(0);
for k = 1:numel(tSeq)
    if ~isvalid(f), return; end
    delete(h);
    G = poseAt(th2ofT(tSeq(k)), D);
    h = drawPose(ax, G, C, 1);
    title(ax, sprintf('\\theta_2 = %.1f^{\\circ},  door pitch = %.1f^{\\circ}', rad2deg(G.th2), G.pitch));
    drawnow;
    if strlength(P.gifFile) > 0
        [im, map] = rgb2ind(frame2im(getframe(f)), 256);
        if k == 1, imwrite(im, map, P.gifFile, 'gif', 'LoopCount', Inf, 'DelayTime', 1/30);
        else,      imwrite(im, map, P.gifFile, 'gif', 'WriteMode', 'append', 'DelayTime', 1/30); end
    else
        pause(1/30);
    end
end
end

function setup3D(ax, lims, vw)
daspect(ax, [1 1 1]);
xlim(ax, lims(1,:));   ylim(ax, lims(2,:));   zlim(ax, lims(3,:));
view(ax, vw);   grid(ax, 'on');   box(ax, 'on');
xlabel(ax, 'x [mm]');   ylabel(ax, 'y [mm]');   zlabel(ax, 'z [mm]');
end

function h = line3(ax, X, col, lw)
h = plot3(ax, X(1,:), X(2,:), X(3,:), '-', 'Color', col, 'LineWidth', lw);
end

function X = circlePts(c, n, R)
n = n/norm(n);
if abs(n(3)) < 0.9, u = cross(n, [0; 0; 1]); else, u = cross(n, [1; 0; 0]); end
u = u/norm(u);   v = cross(n, u);
t = linspace(0, 2*pi, 36);
X = c + R*(u*cos(t) + v*sin(t));
end

function R = rodrigues(n, a)
n = n/norm(n);
K = [0 -n(3) n(2); n(3) 0 -n(1); -n(2) n(1) 0];
R = eye(3) + sin(a)*K + (1 - cos(a))*K*K;
end

function L = swingLimit(s, i)
if isempty(i), L = s(end); else, L = s(max(i - 1, 1)); end
end

function s = rangesText(deg, m)
d  = diff([false m false]);
i0 = find(d == 1);   i1 = find(d == -1) - 1;
if isempty(i0), s = 'none'; return; end
s = strjoin(arrayfun(@(a, b) sprintf('[%.1f, %.1f]', deg(a), deg(b)), i0, i1, 'UniformOutput', false), ', ');
end

function a = wrapPi(a)
a = mod(a + pi, 2*pi) - pi;
end

function c = tint(c, a)
c = 1 - a*(1 - c);
end

function out = pick(cond, a, b)
if cond, out = a; else, out = b; end
end
